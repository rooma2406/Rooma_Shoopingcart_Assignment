
var cartList=[];

function addItemToCart(title, price) {
    cartList.push({title, price});
    onLoadcart();
}

function onLoadcart() {
    let productNumbers = cartList.length;
    if (productNumbers) {
        document.querySelector(`.fa-shopping-cart`).textContent = productNumbers;
    }
}

function popupCartDetails(){
    console.log(cartList)
}

function getCartList(){
    const cars = ["BMW", "Volvo", "Saab", "Ford", "Fiat", "Audi"];
    return cars;
}

